<?php include_once'validation.php'?>
<?php
       $servername = "localhost";
       $username = "root";
       $password = "";
       $dbname = "groupproject";

       // Create connection
       $conn = mysqli_connect($servername, $username, $password, $dbname);
       // Check connection
       if (!$conn) {
           die("Connection failed: " . mysqli_connect_error());
       }
       //Selects data from the database and queries it
      $query ="SELECT * FROM users";
      $result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/form.css">
    <title>Welcome Page</title>
</head>
<body>
    <table  align="center" border="1px" style="width:1100px; line-height:40px">
        <tr>
            <th colspan="9"><h2>Record</h2></th>
        </tr>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>DOB</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Gender</th>
            <th>Picture</th>
            <th>Action</th>

        </tr>
        <?php 
        //A loop to fetch data from the database and display the data in a table
        while($rows=$result->fetch_assoc()){
            ?>
            <tr>
                <td><?php echo $rows['id']; ?></td>
                <td><?php echo $rows['fname']; ?></td>
                <td><?php echo $rows['lname']; ?></td>
                <td><?php echo $rows['dob']; ?></td>
                <td><?php echo $rows['email']; ?></td>
                <td><?php echo $rows['phone']; ?></td>
                <td><?php echo $rows['gender']; ?></td>
                <td><?php echo $rows['avatar'];  ?></td>
                <td> 
                <a href="DisplayForm.php?edit=<?php echo $rows['id'];?>">Edit</a>
                <a href="validation.php?delete=<?php echo $rows['id'];?>">Delete</a>
                </td>
            </tr>
            <?php
            }
            ?>
        
    </table>
</body>
</html>