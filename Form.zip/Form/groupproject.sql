-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 03, 2020 at 10:05 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groupproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(55) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `dob`, `email`, `phone`, `gender`, `avatar`) VALUES
(122, 'odhiambo', 'Jan', '03/27/2000', 'emmanueljan80@gmail.com', '(254) 791-575965', 'Male', '1583143909_1501768567129.jpg'),
(123, 'Ochieng', 'Jan', '03/27/2000', 'emmanueljan80@gmail.com', '(254) 791-575965', 'Male', '1583143950_1501768567129.jpg'),
(94, 'Emmanuel', 'Odhiambo', '01/30/1999', 'ean80@gmail.com', '(254) 791-575965', 'Male', '1582900774_1501768567129.jpg'),
(85, 'Emmanuel', 'Odhiambo', '3/3/1999', 'emmanueljan80@gmail.com', '(254) 791-575965', 'Male', '1582810479_1501768567129.jpg'),
(86, 'Emmanuel', 'Jan', '03/30/2000', 'emmanueljan80@gmail.com', '(254) 791-575945', 'Male', '1582813039_Snapchat-1754181383.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
