<?php include_once 'validation.php'; //including the validation form?> 
<!DOCTYPE html>
  <html>
    <head>
       <link rel="stylesheet" href="assets/css/form.css">
        <title>Group Project</title>
    </head>
        <body>
            <header>
            </header>
            <main>
             <div class="hero">
             <h1 align="center" class="heading">Validation Form(Group Project)</h1>
                <form class="input-group" method="post" enctype="multipart/form-data" action= "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ;?>">
                <div class="form-box">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
               <div>  <label for="fname">First Name*</label><span class="Error"><?php echo $fnameErr; ?></span>
                   <input class="input-field" type="text" name="fname"  placeholder="Enter your first name" autofocus value="<?php echo $firstname; ?>"/>
                </div>

               <div> <label for="lname">Last Name*</label><span class="Error"><?php echo $lnameErr;?></span>
                   <input class="input-field" type="text" name="lname"  placeholder="Enter your last name" value="<?php echo $lastname;?>"/>
                </div>

               <div><label for="DOB">Date of Birth*</label><span class="Error"><?php echo $dobErr;?></span>
                    <input class="input-field" type="text" name="DOB" placeholder="mm/dd/yy" value="<?php echo $Rdob;?>"/>   
                </div> 

               <div> <label for="email">Email Address*</label><span class="Error"><?php echo $emailErr;?></span>
                    <input class="input-field" type="text" name="email"  placeholder="personx@gmail.com" value="<?php echo $Remail;?>"/>
                </div>

                <div> <label for="phoneNumber">Phone Number*</label><span class="Error"><?php echo $phoneNumberErr;?></span>
                    <input class="input-field" type="phone" name="phoneNumber" placeholder="(254) 700-342547" value="<?php echo $RphoneNumber;?>"/>
                </div>

                <div class="gender"><label for="gender">Gender*</label><span class="Error"><?php echo $genderErr;?></span><br>
                    <input type="radio" name="gender"  value="Male">Male 
                    <input type="radio" name="gender" value="Female">Female 
                </div>
                <div><label for="profile">Profile Picture*</label><span class="Error"><?php echo $avatar_pathErr;?></span><br>
                    <input type="file"  name= "avatar" accept="images/*">
                </div>
                <div>
                <?php if ($update==true){?>
                <button type="submit" name="edit" class="submit-btn">Update</button><br>
                <?php }else{?>
                 <button type="submit" name="save-user" class="submit-btn">Submit</button><br>
                <button type="reset" class="submit-btn">Clear</button>
                <?php } ?>
                </div>
            </form>
        </main>
        <footer>
        </footer>
        </div>
    </body>
</html>