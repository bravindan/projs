            <?php
                //defining variables and setting to empty values 
                $fnameErr=$lnameErr=$dobErr=$emailErr=$phoneNumberErr=$genderErr=$avatar_pathErr="";
                $fname=$lname=$dob=$email=$phoneNumber=$gender=$avatar_path="";
                $firstname=$lastname=$Rdob=$Remail=$RphoneNumber=$gender=$avatar_path="";

                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "groupproject";
        
                // Create connection
                $conn = mysqli_connect($servername, $username, $password, $dbname);
                // Check connection
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                $id=0;
                $update=false;
               
 
                if($_SERVER["REQUEST_METHOD"] == "POST"){
                            if(empty($_POST["fname"])){// validation for first name input
                                $fnameErr="(First name is required)";
                            }else{
                                $fname=test_input($_POST["fname"]);
                                if(!preg_match("/^[a-zA-Z]*$/",$fname)){//validation that the name consists of letters and white space only
                                    $fnameErr="(Only letters and white space allowed)";
                                }else{
                                $fname=$conn->real_escape_string($_POST["fname"]);
                                $firstname=$fname;
                                echo $firstname;
                            }
                            }
                            if(empty($_POST["lname"])){// validation for first name input
                                $lnameErr="(Last name is required)";
                            }else{
                            $lname=test_input($_POST["lname"]);
                                if(!preg_match("/^[a-zA-Z]*$/",$lname)){//validation that the name consists of letters and white space only
                                    $lnameErr="(Only letters and white space allowed)";
                                }else{
                                $lname=$conn->real_escape_string($_POST["lname"]);
                                $lastname=$lname;
                                echo $lastname;
                            }
                            }
                            if(empty($_POST["DOB"])){//validation for date input
                                $dobErr="(You must supply a date)";
                        
                            }else{
                                $dob=test_input($_POST["DOB"]);
                                if(!empty($_POST["DOB"])){//validation that the date entered is in correct format
                                    $dt=$_POST["DOB"];
                                    $array = explode("/",$dt);
                                    $day=$array[1];
                                    $month=$array[0];
                                    $year=$array[2];

                                        if(!checkdate($month,$day,$year)){
                                            $dobErr="Invalid date(Date must be in mm/dd/yy format)";
                                        }else{
                                            $dob=$conn->real_escape_string($_POST["DOB"]);
                                            $Rdob=$dob;
                                             echo $Rdob;
                                        }
                                }
                            
                            }
                            if(empty($_POST["email"])){//validation for email input
                                $emailErr="(Email is required)";
                            }else{
                                $email=test_input($_POST["email"]);
                                if(!filter_var($email, FILTER_VALIDATE_EMAIL)){//validation that the email is in the correct format
                                    $emailErr="(Invalid email format)";
                                }else{
                                $email=$conn->real_escape_string($_POST["email"]);
                                $Remail=$email;
                                echo $Remail;
                                }
                            }
                            if(empty($_POST["phoneNumber"])){//validation for phone number input
                                $phoneNumberErr="(Phone number is required)";
                            }else{
                                $phoneNumber=test_input($_POST["phoneNumber"]);
                                if(!preg_match("/^\([0-9]{3}\) [0-9]{3}-[0-9]{6}$/", $_POST["phoneNumber"])){//validation for phone number format
                                    $phoneNumberErr= "(Invalid phone number)";
                                }else{
                                $phoneNumber=$conn->real_escape_string($_POST["phoneNumber"]);
                                $RphoneNumber=$phoneNumber;
                                echo $RphoneNumber;
                                }
                            }
                            if(empty($_POST["gender"])){//validation for gender input
                                $genderErr="(Gender is required)";
                            }else{
                                $gender=test_input($_POST["gender"]);
                                $gender=$conn->real_escape_string($_POST['gender']);
                                echo $gender;
                            }
                             //move image to thumbnails
                             if($_FILES['avatar']['name']){
                                $avatar_path = time().'_'.$_FILES['avatar']['name'];
                                $target = 'images/'.basename($avatar_path);
                                move_uploaded_file($_FILES['avatar']['tmp_name'],$target);
                                echo $avatar_path;
                                 is_uploaded_file($_FILES['avatar']['tmp_name']);
                                 
                            }else{
                                $avatar_pathErr="Image is required";
                            }
                            //ensuring all the fields are entered before transferring the data to the database
                            if(!empty($firstname) and !empty($lastname) and !empty($Rdob) and !empty($Remail)and
                                !empty($RphoneNumber) and !empty($gender)and !empty($avatar_path)){
                                    $sql="INSERT INTO users (fname,lname,dob,email,phone,gender,avatar) 
                                    VALUES ('$firstname','$lastname','$Rdob','$Remail','$RphoneNumber','$gender','$avatar_path')";
                                    if (mysqli_query($conn, $sql)) {
                                        echo "New record created successfully";
                                    } else {
                                        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                                    }
                                
                                mysqli_close($conn);
                                //the header function redirects to the welcome.php file  
                                    header("refresh:1;url=welcome.php");
                                }
                           
            }
                //A function that does all the checking...
                function test_input($data){
                    $data=trim($data);//the function strips unnecessary characters from user input data
                    $data=stripslashes($data);//the function removes backslashes from the user input data
                    $data=htmlspecialchars($data);//input data is saved as HTML escape code
                    return $data;
                } 
                //when the delete link is clicked the code to delete the respective row is executed...
                if(isset($_GET['delete'])){
                    $id = $_GET['delete'];
                    $conn->query("DELETE FROM users WHERE id=$id") or die($conn->error());
                    header("refresh:1;url=welcome.php");
                }
                if(isset($_GET['edit'])){
                    $id=$_GET['edit'];
                    $update=true;
                    $result=$conn->query("SELECT * FROM users WHERE id=$id") or die($conn->error());
                    
                        $rows=$result->fetch_array();
                       // $id=$rows['id'];
                        $firstname=$rows['fname'];
                        $lastname=$rows['lname'];
                        $Rdob=$rows['dob'];
                        $Remail=$rows['email'];
                        $RphoneNumber=$rows['phone'];
                        $gender=$rows['gender'];
                        $avatar_path=$rows['avatar'];
                        
                    
                }

                if(isset($_POST['update'])){
                    $id=$_POST['id'];
                    $firstname=$_POST['fname'];
                    $lastname=$_POST['lname'];
                    $Rdob=$_POST['dob'];
                    $Remail=$_POST['email'];
                    $RphoneNumber=$_POST['phone'];
                    $gender=$_POST['gender'];
                    $avatar_path=$_POST['avatar'];

                    $mysql->query("UPDATE users SET fname='$firstname',lname='$lastname',dob='$Rdob',
                    email='$Remail',phone='$RphoneNumber',gender='$gender',avatar='$avatar_path'
                     WHERE id=$id")or die($conn->error());
                     
                     header("refresh:1;url=welcome.php");
                }
            ?>  